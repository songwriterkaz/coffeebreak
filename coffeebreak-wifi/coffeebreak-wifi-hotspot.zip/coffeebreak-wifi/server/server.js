// Coffeebreak WiFi - hotspot welcome portal
// (c) Karen O'Brien (Coffeebreak). All rights reserved.
// No dependencies. Needs Node.js 18 or newer.
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');

const PORT = parseInt(process.env.PORT || '80', 10);
const HOST = process.env.HOST || '0.0.0.0';
const SSID = process.env.SSID || 'Coffeebreak WiFi';
const MAIL_PORT = parseInt(process.env.MAIL_PORT || '8080', 10);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const LOG_FILE = path.join(DATA_DIR, 'signins.jsonl');
const PUBLIC = path.join(__dirname, 'public');
// Linux only: when set, accepted client IPs are added to this ipset so the firewall lets them through.
const IPSET = process.env.IPSET || '';
const ADMIN_PASS = process.env.ADMIN_PASS || crypto.randomBytes(6).toString('hex');

fs.mkdirSync(DATA_DIR, { recursive: true });

const accepted = new Map(); // ip -> time accepted
const sessions = new Map(); // token -> ip
const SESSION_HOURS = parseFloat(process.env.SESSION_HOURS || '12');

function clientIp(req) {
  let ip = req.socket.remoteAddress || '';
  if (ip.startsWith('::ffff:')) ip = ip.slice(7);
  return ip;
}
function isAccepted(ip) {
  const t = accepted.get(ip);
  if (!t) return false;
  if (Date.now() - t > SESSION_HOURS * 3600e3) { accepted.delete(ip); return false; }
  return true;
}
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function send(res, code, body, type = 'text/html; charset=utf-8', extra = {}) {
  res.writeHead(code, Object.assign({ 'Content-Type': type, 'Cache-Control': 'no-store' }, extra));
  res.end(body);
}
function redirect(res, loc) {
  res.writeHead(302, { Location: loc, 'Cache-Control': 'no-store' });
  res.end();
}
function readBody(req, limit = 1e5) {
  return new Promise((resolve, reject) => {
    let b = '';
    req.on('data', c => { b += c; if (b.length > limit) { reject(new Error('too large')); req.destroy(); } });
    req.on('end', () => resolve(b));
    req.on('error', reject);
  });
}
function portalHost(req) {
  // Address clients should use to reach this laptop.
  const h = (req.headers.host || '').split(':')[0];
  return process.env.PORTAL_HOST || h || 'localhost';
}
function portalUrl(req) {
  const h = portalHost(req);
  return 'http://' + h + (PORT === 80 ? '' : ':' + PORT) + '/';
}
function checkMail() {
  return new Promise(resolve => {
    const r = http.get({ host: '127.0.0.1', port: MAIL_PORT, path: '/', timeout: 800 }, res => { res.resume(); resolve(true); });
    r.on('error', () => resolve(false));
    r.on('timeout', () => { r.destroy(); resolve(false); });
  });
}
function readLog() {
  if (!fs.existsSync(LOG_FILE)) return [];
  return fs.readFileSync(LOG_FILE, 'utf8').split('\n').filter(Boolean).map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
}
function allowFirewall(ip) {
  if (!IPSET || !/^[0-9.]+$/.test(ip)) return;
  execFile('ipset', ['-exist', 'add', IPSET, ip], err => { if (err) console.error('ipset add failed:', err.message); });
}

const template = fs.readFileSync(path.join(PUBLIC, 'splash.html'), 'utf8');
const adminTpl = fs.readFileSync(path.join(PUBLIC, 'admin.html'), 'utf8');

async function splash(req, res, opts = {}) {
  const mailUp = await checkMail();
  const mailUrl = 'http://' + portalHost(req) + ':' + MAIL_PORT + '/';
  const html = template
    .replace(/{{SSID}}/g, () => esc(SSID))
    .replace('{{STATE}}', () => opts.done ? 'done' : 'signin')
    .replace('{{ERROR}}', () => esc(opts.error || ''))
    .replace('{{NAME}}', () => opts.name ? ', ' + esc(opts.name) : '')
    .replace('{{MAIL}}', () => mailUp
      ? '<a class="btn alt" href="' + esc(mailUrl) + '">Open Coffeebreak Mail</a><p class="small">Free local email between people on this hotspot.</p>'
      : '<p class="small">Coffeebreak Mail is not running on this hotspot right now.</p>');
  send(res, 200, html);
}

const CAPTIVE_PATHS = new Set([
  '/generate_204', '/gen_204', '/hotspot-detect.html', '/library/test/success.html',
  '/connecttest.txt', '/ncsi.txt', '/redirect', '/success.txt', '/canonical.html', '/check_network_status.txt'
]);

function adminAuth(req) {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Basic ')) return false;
  const [, pass] = Buffer.from(h.slice(6), 'base64').toString().split(':');
  const a = Buffer.from(String(pass || '')), b = Buffer.from(ADMIN_PASS);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    const p = url.pathname;
    const ip = clientIp(req);
    const ownHost = (req.headers.host || '').split(':')[0];

    // Captive portal probes from phones and laptops.
    if (CAPTIVE_PATHS.has(p)) {
      if (isAccepted(ip)) {
        if (p === '/generate_204' || p === '/gen_204') { res.writeHead(204); return res.end(); }
        if (p === '/connecttest.txt') return send(res, 200, 'Microsoft Connect Test', 'text/plain');
        if (p === '/ncsi.txt') return send(res, 200, 'Microsoft NCSI', 'text/plain');
        if (p === '/success.txt') return send(res, 200, 'success\n', 'text/plain');
        if (p === '/canonical.html') return send(res, 200, '<meta http-equiv="refresh" content="0;url=https://support.mozilla.org/kb/captive-portal"/>');
        return send(res, 200, '<HTML><HEAD><TITLE>Success</TITLE></HEAD><BODY>Success</BODY></HTML>');
      }
      return redirect(res, portalUrl(req));
    }

    if (p === '/logo.png' || p === '/favicon.ico') {
      res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'max-age=86400' });
      return fs.createReadStream(path.join(PUBLIC, 'logo.png')).pipe(res);
    }

    if (p === '/api/status') {
      return send(res, 200, JSON.stringify({ ssid: SSID, accepted: isAccepted(ip), mail: await checkMail(), mailPort: MAIL_PORT, clients: accepted.size }), 'application/json');
    }

    if (p === '/accept' && req.method === 'POST') {
      const body = new URLSearchParams(await readBody(req));
      const name = (body.get('name') || '').trim().slice(0, 80);
      const email = (body.get('email') || '').trim().slice(0, 120);
      if (body.get('terms') !== 'yes') return splash(req, res, { error: 'Please tick the box to accept the terms of use.' });
      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return splash(req, res, { error: 'That email address does not look right. Leave it blank if you prefer.' });
      accepted.set(ip, Date.now());
      const token = crypto.randomBytes(16).toString('hex');
      sessions.set(token, ip);
      const entry = { time: new Date().toISOString(), ip, name, email, ua: String(req.headers['user-agent'] || '').slice(0, 200) };
      fs.appendFileSync(LOG_FILE, JSON.stringify(entry) + '\n');
      allowFirewall(ip);
      console.log('Accepted', ip, name || '(no name)');
      res.setHeader('Set-Cookie', 'cbwifi=' + token + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=' + Math.round(SESSION_HOURS * 3600));
      return splash(req, res, { done: true, name });
    }

    if (p === '/admin' || p === '/admin/export.csv') {
      if (!adminAuth(req)) {
        res.writeHead(401, { 'WWW-Authenticate': 'Basic realm="Coffeebreak WiFi admin"' });
        return res.end('Admin password needed');
      }
      const rows = readLog();
      if (p === '/admin/export.csv') {
        const q = v => { let t = String(v || ''); if (/^[=+\-@]/.test(t)) t = "'" + t; return '"' + t.replace(/"/g, '""') + '"'; };
        const csv = 'time,ip,name,email,device\n' + rows.map(r => [r.time, r.ip, r.name, r.email, r.ua].map(q).join(',')).join('\n') + '\n';
        return send(res, 200, csv, 'text/csv', { 'Content-Disposition': 'attachment; filename="coffeebreak-wifi-signins.csv"' });
      }
      const mailUp = await checkMail();
      const tr = rows.slice().reverse().map(r => '<tr><td>' + esc(r.time.replace('T', ' ').slice(0, 19)) + '</td><td>' + esc(r.name) + '</td><td>' + esc(r.email) + '</td><td>' + esc(r.ip) + '</td></tr>').join('');
      return send(res, 200, adminTpl
        .replace(/{{SSID}}/g, () => esc(SSID))
        .replace('{{ONLINE}}', () => String(accepted.size))
        .replace('{{TOTAL}}', () => String(rows.length))
        .replace('{{MAIL}}', () => mailUp ? 'Running on port ' + MAIL_PORT : 'Not running')
        .replace('{{ROWS}}', () => tr || '<tr><td colspan="4">No sign-ins yet.</td></tr>'));
    }

    if (p === '/' || p === '/index.html' || p === '/welcome') {
      if (isAccepted(ip)) return splash(req, res, { done: true });
      return splash(req, res);
    }

    // Any other request (redirected web traffic on Linux) goes to the welcome page.
    if (ownHost && ownHost !== portalHost(req)) return redirect(res, portalUrl(req));
    return redirect(res, '/');
  } catch (e) {
    console.error(e);
    send(res, 500, 'Something went wrong', 'text/plain');
  }
});

if (require.main === module) {
  server.listen(PORT, HOST, () => {
    console.log('Coffeebreak WiFi portal running on http://' + (HOST === '0.0.0.0' ? 'localhost' : HOST) + ':' + PORT + '/');
    console.log('Network name: ' + SSID);
    console.log('Admin page: /admin  (any username, password: ' + ADMIN_PASS + ')');
    if (IPSET) console.log('Linux firewall mode: accepted devices are added to ipset "' + IPSET + '"');
  });
}
module.exports = { server, ADMIN_PASS };
