@echo off
rem Coffeebreak WiFi - start the welcome portal on Windows (run as Administrator for port 80)
cd /d "%~dp0\.."
set PORT=80
node server.js
pause
