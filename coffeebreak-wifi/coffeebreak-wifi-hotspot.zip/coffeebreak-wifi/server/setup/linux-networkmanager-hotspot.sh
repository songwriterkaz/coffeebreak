#!/bin/bash
# Coffeebreak WiFi - simple Linux hotspot with NetworkManager (no automatic redirect)
# Use this if you just want the hotspot and welcome page, without hostapd/dnsmasq.
#   sudo bash setup/linux-networkmanager-hotspot.sh
WIFI_IF="${WIFI_IF:-wlan0}"
SSID="${SSID:-Coffeebreak WiFi}"
read -r -s -p "Choose a hotspot password (8 or more characters): " PASS; echo
nmcli dev wifi hotspot ifname "$WIFI_IF" ssid "$SSID" password "$PASS"
IP=$(ip -4 addr show "$WIFI_IF" | awk '/inet /{print $2}' | cut -d/ -f1)
echo "Hotspot on. Guests open http://$IP to see the welcome page."
cd "$(dirname "$0")/.."
PORT=80 PORTAL_HOST="$IP" SSID="$SSID" node server.js
