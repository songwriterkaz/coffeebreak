# Coffeebreak WiFi - Windows 10/11 Mobile Hotspot setup
# Run in PowerShell as Administrator, from the server folder:
#   powershell -ExecutionPolicy Bypass -File setup\windows-mobile-hotspot.ps1
# Internet comes from this PC's own connection and data plan.

$ErrorActionPreference = "Stop"
$SSID = "Coffeebreak WiFi"
$Pass = Read-Host "Choose a hotspot password (8 or more characters)"
if ($Pass.Length -lt 8) { Write-Host "Password must be 8 or more characters."; exit 1 }

Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, [Type]$t) { $task = $asTaskGeneric.MakeGenericMethod($t).Invoke($null, @($op)); $task.Wait(-1) | Out-Null; $task.Result }

$profile = [Windows.Networking.Connectivity.NetworkInformation,Windows.Networking.Connectivity,ContentType=WindowsRuntime]::GetInternetConnectionProfile()
if (-not $profile) { Write-Host "No internet connection found. Connect this PC to the internet first."; exit 1 }
$mgr = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager,Windows.Networking.NetworkOperators,ContentType=WindowsRuntime]::CreateFromConnectionProfile($profile)

$cfg = $mgr.GetCurrentAccessPointConfiguration()
$cfg.Ssid = $SSID
$cfg.Passphrase = $Pass
$asTaskAction = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' })[0]
$asTaskAction.Invoke($null, @($mgr.ConfigureAccessPointAsync($cfg))).Wait(-1) | Out-Null
$result = Await ($mgr.StartTetheringAsync()) ([Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult])
Write-Host "Hotspot status:" $result.Status

# Allow the portal through Windows Firewall
New-NetFirewallRule -DisplayName "Coffeebreak WiFi portal" -Direction Inbound -Protocol TCP -LocalPort 80 -Action Allow -ErrorAction SilentlyContinue | Out-Null

Write-Host ""
Write-Host "Hotspot '$SSID' is on. Windows hotspots usually use the address 192.168.137.1"
Write-Host "Now start the portal in this window:  node server.js"
Write-Host "Guests open http://192.168.137.1 to see the Coffeebreak WiFi welcome page."
Write-Host "Windows does not redirect guests to the page automatically. Put a sign or QR code up with that address."
