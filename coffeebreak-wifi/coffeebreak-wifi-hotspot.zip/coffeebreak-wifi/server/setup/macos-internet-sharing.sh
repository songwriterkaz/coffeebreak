#!/bin/bash
# Coffeebreak WiFi - macOS Internet Sharing helper
# macOS does not let scripts switch Internet Sharing on safely, so do these steps once by hand:
#   1. System Settings > General > Sharing > Internet Sharing > (i)
#   2. Share your connection from: Ethernet, iPhone USB or Thunderbolt (the Mac's internet)
#   3. To devices using: Wi-Fi
#   4. Wi-Fi Options: Network Name "Coffeebreak WiFi", Security WPA2/WPA3 Personal, choose a password
#   5. Turn Internet Sharing on
# Note: the Mac's Wi-Fi cannot share the same Wi-Fi it is connected to. Use Ethernet or a phone over USB.
# Then run this script:  sudo bash setup/macos-internet-sharing.sh
cd "$(dirname "$0")/.."
IP=$(ipconfig getifaddr bridge100 2>/dev/null || echo 192.168.2.1)
echo "Internet Sharing address: $IP"
echo "Guests open http://$IP to see the Coffeebreak WiFi welcome page."
echo "macOS does not redirect guests to the page automatically. Put a sign or QR code up with that address."
PORT=80 PORTAL_HOST="$IP" node server.js
