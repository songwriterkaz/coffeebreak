#!/bin/bash
# Coffeebreak WiFi - Linux hotspot with automatic captive portal
# Tested layout: Debian/Ubuntu/Raspberry Pi OS. Run as root:
#   sudo bash setup/linux-hotspot-captive.sh start      (start hotspot, firewall and portal)
#   sudo bash setup/linux-hotspot-captive.sh stop       (undo firewall rules and stop hotspot)
# Needs: hostapd, dnsmasq, iptables, ipset, nodejs (18+)
#   sudo apt install hostapd dnsmasq iptables ipset nodejs
# Settings (override with environment variables):
WIFI_IF="${WIFI_IF:-wlan0}"          # Wi-Fi card that will broadcast the hotspot
WAN_IF="${WAN_IF:-eth0}"             # Interface with the internet (eth0, usb0 for a phone, wwan0)
SSID="${SSID:-Coffeebreak WiFi}"
PASS="${PASS:-}"                     # Leave blank for an open network, or set 8+ characters
GW="${GW:-192.168.50.1}"
SET=cbwifi_allowed
DIR="$(cd "$(dirname "$0")/.." && pwd)"
RUN=/run/coffeebreak-wifi
set -e

stop() {
  iptables -t nat -D PREROUTING -i "$WIFI_IF" -p tcp --dport 80 -m set ! --match-set $SET src -j DNAT --to-destination "$GW:80" 2>/dev/null || true
  iptables -D FORWARD -i "$WIFI_IF" -o "$WAN_IF" -m set --match-set $SET src -j ACCEPT 2>/dev/null || true
  iptables -D FORWARD -i "$WIFI_IF" -o "$WAN_IF" -j DROP 2>/dev/null || true
  iptables -D FORWARD -i "$WAN_IF" -o "$WIFI_IF" -m state --state RELATED,ESTABLISHED -j ACCEPT 2>/dev/null || true
  iptables -t nat -D POSTROUTING -o "$WAN_IF" -j MASQUERADE 2>/dev/null || true
  [ -f $RUN/hostapd.pid ] && kill "$(cat $RUN/hostapd.pid)" 2>/dev/null || true
  [ -f $RUN/dnsmasq.pid ] && kill "$(cat $RUN/dnsmasq.pid)" 2>/dev/null || true
  ipset destroy $SET 2>/dev/null || true
  command -v nmcli >/dev/null && nmcli dev set "$WIFI_IF" managed yes 2>/dev/null || true
  echo "Coffeebreak WiFi stopped."
}

start() {
  mkdir -p $RUN
  command -v nmcli >/dev/null && nmcli dev set "$WIFI_IF" managed no 2>/dev/null || true
  ip link set "$WIFI_IF" up
  ip addr flush dev "$WIFI_IF"
  ip addr add "$GW/24" dev "$WIFI_IF"

  cat > $RUN/hostapd.conf <<CONF
interface=$WIFI_IF
driver=nl80211
ssid=$SSID
utf8_ssid=1
hw_mode=g
channel=6
CONF
  if [ -n "$PASS" ]; then
    printf 'wpa=2\nwpa_key_mgmt=WPA-PSK\nrsn_pairwise=CCMP\nwpa_passphrase=%s\n' "$PASS" >> $RUN/hostapd.conf
  fi
  hostapd -B -P $RUN/hostapd.pid $RUN/hostapd.conf

  # DHCP and DNS for guests. DNS is forwarded normally; web traffic is redirected by the firewall below.
  # dhcp-option 114 tells newer phones where the portal is (RFC 8910).
  dnsmasq --interface="$WIFI_IF" --bind-interfaces --except-interface=lo \
    --dhcp-range=192.168.50.10,192.168.50.250,12h --dhcp-option=3,"$GW" --dhcp-option=6,"$GW" \
    --dhcp-option=114,"http://$GW/" --address=/coffeebreak.wifi/"$GW" --pid-file=$RUN/dnsmasq.pid

  sysctl -qw net.ipv4.ip_forward=1
  ipset -exist create $SET hash:ip timeout 43200
  iptables -t nat -A POSTROUTING -o "$WAN_IF" -j MASQUERADE
  iptables -A FORWARD -i "$WAN_IF" -o "$WIFI_IF" -m state --state RELATED,ESTABLISHED -j ACCEPT
  iptables -A FORWARD -i "$WIFI_IF" -o "$WAN_IF" -m set --match-set $SET src -j ACCEPT
  iptables -A FORWARD -i "$WIFI_IF" -o "$WAN_IF" -j DROP
  # Until a device accepts the terms, its web requests go to the welcome page.
  iptables -t nat -A PREROUTING -i "$WIFI_IF" -p tcp --dport 80 -m set ! --match-set $SET src -j DNAT --to-destination "$GW:80"

  echo "Coffeebreak WiFi is on: '$SSID'. Welcome page at http://$GW/ (also http://coffeebreak.wifi/)"
  echo "Press Ctrl+C to stop the portal, then run: sudo bash $0 stop"
  cd "$DIR"
  PORT=80 HOST="$GW" PORTAL_HOST="$GW" SSID="$SSID" IPSET=$SET node server.js
}

case "$1" in
  start) start ;;
  stop) stop ;;
  *) echo "Usage: sudo bash $0 start|stop"; exit 1 ;;
esac
