'use strict';
// Creates a DKIM key pair: dkim-private.pem (keep secret) and prints the DNS TXT record.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const selector = process.argv[2] || 'cbmail';
const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const out = path.join(__dirname, '..', 'dkim-private.pem');
fs.writeFileSync(out, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
const pub = publicKey.export({ type: 'spki', format: 'der' }).toString('base64');
console.log(`Private key saved to ${out}\n\nAdd this DNS TXT record:\n  Name:  ${selector}._domainkey\n  Value: v=DKIM1; k=rsa; p=${pub}`);
