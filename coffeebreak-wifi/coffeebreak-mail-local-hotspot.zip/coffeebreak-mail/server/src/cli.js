'use strict';
// Usage: node src/cli.js add-user <username> [display name]
// The password is read from the PASSWORD env var or typed at a hidden prompt,
// so it never ends up in shell history.
const config = require('./config');
const Store = require('./store');
const [cmd, username, ...rest] = process.argv.slice(2);
if (cmd !== 'add-user' || !username) { console.log('Usage: node src/cli.js add-user <username> [display name]'); process.exit(1); }
function ask(q) {
  return new Promise((resolve) => {
    const rl = require('readline').createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    rl._writeToOutput = (s) => { if (s.includes(q)) process.stdout.write(s); };
    rl.question(q, (a) => { rl.close(); process.stdout.write('\n'); resolve(a); });
  });
}
(async () => {
  const pw = process.env.PASSWORD || (await ask('Password (8+ characters): '));
  try { new Store(config.dataDir).addUser(username, pw, rest.join(' ') || undefined); console.log(`Created ${username.toLowerCase()}@${config.domain}`); }
  catch (e) { console.error(e.message); process.exit(1); }
})();
