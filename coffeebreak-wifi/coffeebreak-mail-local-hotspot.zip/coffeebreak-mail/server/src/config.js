'use strict';
// Coffeebreak Mail server config loader.
// Settings come from config.json (next to package.json, or CONFIG_FILE env var),
// with environment variables overriding. Secrets (relay password, DKIM key) are
// only ever read from this local file or env. They are never sent to the web app
// and never written to logs.
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const file = process.env.CONFIG_FILE || path.join(ROOT, 'config.json');
let fromFile = {};
if (fs.existsSync(file)) {
  fromFile = JSON.parse(fs.readFileSync(file, 'utf8'));
}
const env = process.env;
const bool = (v, d) => (v === undefined ? d : /^(1|true|yes|on)$/i.test(String(v)));
const relayFile = fromFile.outsideMail || {};

const config = {
  domain: (env.MAIL_DOMAIN || fromFile.domain || 'coffeebreak.local').toLowerCase(),
  hostname: env.MAIL_HOSTNAME || fromFile.hostname || 'mail.' + (env.MAIL_DOMAIN || fromFile.domain || 'coffeebreak.local'),
  smtpPort: Number(env.SMTP_PORT || fromFile.smtpPort || 25),
  apiPort: Number(env.API_PORT || fromFile.apiPort || 8080),
  apiHost: env.API_HOST || fromFile.apiHost || '0.0.0.0',
  smtpHost: env.SMTP_HOST || fromFile.smtpHost || '0.0.0.0',
  dataDir: path.resolve(ROOT, env.DATA_DIR || fromFile.dataDir || 'data'),
  allowSignup: bool(env.ALLOW_SIGNUP, fromFile.allowSignup !== undefined ? fromFile.allowSignup : true),
  corsOrigin: env.CORS_ORIGIN || fromFile.corsOrigin || '*',
  maxMessageBytes: Number(env.MAX_MESSAGE_BYTES || fromFile.maxMessageBytes || 25 * 1024 * 1024),
  // Direct delivery to other domains' MX servers on port 25 (needs a real domain,
  // a VPS with port 25 open, SPF/DKIM/DMARC). Off by default.
  directDelivery: bool(env.DIRECT_DELIVERY, !!fromFile.directDelivery),
  dkim: fromFile.dkim && fromFile.dkim.privateKeyFile ? {
    domainName: fromFile.dkim.domainName || (env.MAIL_DOMAIN || fromFile.domain),
    keySelector: fromFile.dkim.keySelector || 'cbmail',
    privateKey: fs.readFileSync(path.resolve(ROOT, fromFile.dkim.privateKeyFile), 'utf8'),
  } : null,
  // Optional "Outside mail" relay: send mail for non-local addresses through the
  // owner's own email account (e.g. Gmail with an app password).
  outsideMail: {
    enabled: bool(env.RELAY_ENABLED, !!relayFile.enabled),
    host: env.RELAY_HOST || relayFile.host || '',
    port: Number(env.RELAY_PORT || relayFile.port || 587),
    secure: bool(env.RELAY_SECURE, !!relayFile.secure),        // true for port 465
    user: env.RELAY_USER || relayFile.user || '',
    pass: env.RELAY_PASS || relayFile.pass || '',
    fromAddress: env.RELAY_FROM || relayFile.fromAddress || relayFile.user || '',
    fromName: relayFile.fromName || 'Coffeebreak Mail',
    rejectUnauthorized: relayFile.rejectUnauthorized !== undefined ? !!relayFile.rejectUnauthorized : true,
    dailyLimit: Number(env.RELAY_DAILY_LIMIT || relayFile.dailyLimit || 400),
  },
};

config.publicSummary = () => ({
  domain: config.domain,
  outsideMail: config.outsideMail.enabled
    ? { enabled: true, sendsAs: config.outsideMail.fromAddress, dailyLimit: config.outsideMail.dailyLimit }
    : { enabled: false },
  directDelivery: config.directDelivery,
  allowSignup: config.allowSignup,
});

module.exports = config;
