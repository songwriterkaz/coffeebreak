'use strict';
// Coffeebreak Mail server: SMTP receiving + REST API + optional static web client.
// (c) Karen O'Brien (Coffeebreak). All rights reserved.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { SMTPServer } = require('smtp-server');
const { simpleParser } = require('mailparser');
const config = require('./config');
const Store = require('./store');
const { Mailer, splitAddr } = require('./mailer');
const log = require('./log');

const store = new Store(config.dataDir);
const mailer = new Mailer(config, store);
const sessions = new Map(); // sha256(token) -> { user, exp }
const SESSION_MS = 7 * 24 * 3600 * 1000;
const FOLDERS = ['inbox', 'sent', 'drafts', 'trash'];

// ---------------- SMTP (receiving) ----------------
const smtp = new SMTPServer({
  name: config.hostname,
  banner: 'Coffeebreak Mail',
  authOptional: true,
  disabledCommands: ['AUTH'],          // inbound only; users send through the API
  size: config.maxMessageBytes,
  logger: false,
  onRcptTo(address, session, cb) {
    const a = splitAddr(address.address);
    if (!a || a.domain !== config.domain) return cb(Object.assign(new Error('Relaying denied'), { responseCode: 550 }));
    if (!store.hasUser(a.local)) return cb(Object.assign(new Error('No such user here'), { responseCode: 550 }));
    cb();
  },
  onData(stream, session, cb) {
    simpleParser(stream, { skipImageLinks: true }).then((p) => {
      if (stream.sizeExceeded) return cb(Object.assign(new Error('Message too big'), { responseCode: 552 }));
      const msg = {
        from: p.from && p.from.value[0] ? { name: p.from.value[0].name || '', address: p.from.value[0].address || '' } : { name: '', address: session.envelope.mailFrom.address || '' },
        to: (p.to ? [].concat(p.to).flatMap((x) => x.value.map((v) => v.address)) : []),
        cc: (p.cc ? [].concat(p.cc).flatMap((x) => x.value.map((v) => v.address)) : []),
        subject: p.subject || '(no subject)',
        text: p.text || (p.html ? String(p.html).replace(/<[^>]+>/g, ' ') : ''),
        date: (p.date || new Date()).toISOString(),
        messageId: p.messageId || null,
        inReplyTo: p.inReplyTo || null,
        attachments: (p.attachments || []).map((x) => ({ filename: x.filename, size: x.size, contentType: x.contentType })),
        folder: 'inbox',
      };
      for (const r of session.envelope.rcptTo) {
        const a = splitAddr(r.address);
        store.addMessage(a.local, msg);
      }
      log.info(`smtp: received message for ${session.envelope.rcptTo.length} local recipient(s)`);
      cb(null, 'Queued in Coffeebreak Mail');
    }).catch((e) => { log.warn('smtp parse failed: ' + e.message); cb(new Error('Could not read message')); });
  },
});
smtp.on('error', (e) => log.warn('smtp error: ' + e.message));

// ---------------- REST API ----------------
const failures = new Map(); // ip -> { n, until }
function tooManyFails(ip) { const f = failures.get(ip); return f && f.n >= 10 && f.until > Date.now(); }
function noteFail(ip) { const f = failures.get(ip) || { n: 0, until: 0 }; f.n++; f.until = Date.now() + 15 * 60 * 1000; failures.set(ip, f); }

function send(res, code, body) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
}
function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 5 * 1024 * 1024) { reject(new Error('Too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { reject(new Error('Bad JSON')); } });
    req.on('error', reject);
  });
}
const sha = (t) => crypto.createHash('sha256').update(t).digest('hex');
function newSession(user) { const t = crypto.randomBytes(32).toString('base64url'); sessions.set(sha(t), { user, exp: Date.now() + SESSION_MS }); return t; }
function auth(req) {
  const m = (req.headers.authorization || '').match(/^Bearer (.+)$/);
  if (!m) return null;
  const s = sessions.get(sha(m[1]));
  if (!s || s.exp < Date.now()) return null;
  return s.user;
}
const summary = (m) => ({ id: m.id, folder: m.folder, from: m.from, to: m.to, cc: m.cc, subject: m.subject, date: m.date, read: m.read, starred: m.starred, snippet: String(m.text || '').slice(0, 140), delivery: m.delivery });
const me = (u) => ({ username: u, address: `${u}@${config.domain}`, displayName: store.users[u].displayName });

const WEB_DIR = path.resolve(__dirname, '..', process.env.WEB_DIR || '../web');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
function serveStatic(req, res, p) {
  if (!fs.existsSync(WEB_DIR)) return send(res, 404, { error: 'Not found' });
  let f = path.normalize(path.join(WEB_DIR, decodeURIComponent(p)));
  if (!f.startsWith(WEB_DIR)) return send(res, 403, { error: 'Forbidden' });
  if (fs.existsSync(f) && fs.statSync(f).isDirectory()) f = path.join(f, 'index.html');
  if (!fs.existsSync(f)) return send(res, 404, { error: 'Not found' });
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
}

async function handle(req, res) {
  res.setHeader('Access-Control-Allow-Origin', config.corsOrigin);
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  const ip = req.socket.remoteAddress;
  if (!p.startsWith('/api/')) return serveStatic(req, res, p);

  if (p === '/api/info' && req.method === 'GET') return send(res, 200, { name: 'Coffeebreak Mail', version: '1.0.0', ...config.publicSummary() });

  if (p === '/api/register' && req.method === 'POST') {
    if (!config.allowSignup) return send(res, 403, { error: 'Sign up is turned off on this server' });
    const b = await readJson(req);
    try { store.addUser(b.username, b.password, b.displayName); } catch (e) { return send(res, 400, { error: e.message }); }
    const u = String(b.username).toLowerCase();
    log.info(`api: new user ${u}`);
    return send(res, 201, { token: newSession(u), user: me(u) });
  }
  if (p === '/api/login' && req.method === 'POST') {
    if (tooManyFails(ip)) return send(res, 429, { error: 'Too many tries. Wait 15 minutes.' });
    const b = await readJson(req);
    const u = store.checkLogin(String(b.username || ''), String(b.password || ''));
    if (!u) { noteFail(ip); return send(res, 401, { error: 'Wrong username or password' }); }
    failures.delete(ip);
    return send(res, 200, { token: newSession(u.username), user: me(u.username) });
  }

  const user = auth(req);
  if (!user) return send(res, 401, { error: 'Please log in' });
  const box = store.box(user);

  if (p === '/api/logout' && req.method === 'POST') { sessions.delete(sha(req.headers.authorization.slice(7))); return send(res, 200, { ok: true }); }
  if (p === '/api/me' && req.method === 'GET') return send(res, 200, { user: me(user), server: config.publicSummary() });

  if (p === '/api/messages' && req.method === 'GET') {
    const folder = url.searchParams.get('folder');
    const q = (url.searchParams.get('q') || '').toLowerCase();
    let list = box.messages.filter((m) => (!folder || m.folder === folder));
    if (q) list = list.filter((m) => [m.subject, m.text, m.from && m.from.address, m.from && m.from.name, ...(m.to || [])].join(' ').toLowerCase().includes(q));
    list.sort((a, b) => (a.date < b.date ? 1 : -1));
    const counts = {}; FOLDERS.forEach((f) => (counts[f] = box.messages.filter((m) => m.folder === f && (f !== 'inbox' || !m.read)).length));
    return send(res, 200, { messages: list.map(summary), unread: counts });
  }
  let m = p.match(/^\/api\/messages\/([\w-]+)$/);
  if (m) {
    const msg = box.messages.find((x) => x.id === m[1]);
    if (!msg) return send(res, 404, { error: 'Message not found' });
    if (req.method === 'GET') return send(res, 200, { message: msg });
    if (req.method === 'PATCH') {
      const b = await readJson(req);
      if (b.folder && FOLDERS.includes(b.folder)) msg.folder = b.folder;
      if (typeof b.read === 'boolean') msg.read = b.read;
      if (typeof b.starred === 'boolean') msg.starred = b.starred;
      if (msg.folder === 'drafts') ['to', 'cc', 'subject', 'text'].forEach((k) => { if (b[k] !== undefined) msg[k] = b[k]; });
      store.save(user); return send(res, 200, { message: msg });
    }
    if (req.method === 'DELETE') {
      if (msg.folder === 'trash') box.messages = box.messages.filter((x) => x !== msg); else msg.folder = 'trash';
      store.save(user); return send(res, 200, { ok: true });
    }
  }
  if (p === '/api/drafts' && req.method === 'POST') {
    const b = await readJson(req);
    const d = store.addMessage(user, { folder: 'drafts', read: true, from: { name: store.users[user].displayName, address: `${user}@${config.domain}` }, to: [].concat(b.to || []), cc: [].concat(b.cc || []), subject: b.subject || '', text: b.text || '' });
    return send(res, 201, { message: d });
  }
  if (p === '/api/send' && req.method === 'POST') {
    const b = await readJson(req);
    const list = (v) => [].concat(v || []).flatMap((x) => String(x).split(/[,;]/)).map((s) => s.trim()).filter(Boolean);
    let out;
    try { out = await mailer.send({ fromUser: user, to: list(b.to), cc: list(b.cc), subject: b.subject, text: b.text, inReplyTo: b.inReplyTo }); }
    catch (e) { return send(res, 400, { error: e.message }); }
    const sent = store.addMessage(user, { ...out.base, folder: 'sent', read: true, delivery: out.results });
    if (b.draftId) { box.messages = box.messages.filter((x) => x.id !== b.draftId); store.save(user); }
    // auto-add recipients to contacts
    out.results.forEach((r) => { if (r.ok && !box.contacts.some((c) => c.email === r.to)) box.contacts.push({ id: crypto.randomUUID(), name: r.to.split('@')[0], email: r.to }); });
    store.save(user);
    return send(res, 200, { ok: out.results.every((r) => r.ok), results: out.results, message: summary(sent) });
  }
  if (p === '/api/contacts' && req.method === 'GET') return send(res, 200, { contacts: box.contacts });
  if (p === '/api/contacts' && req.method === 'POST') {
    const b = await readJson(req);
    if (!splitAddr(b.email || '')) return send(res, 400, { error: 'Enter a valid email address' });
    const c = { id: crypto.randomUUID(), name: String(b.name || '').slice(0, 80) || b.email, email: String(b.email).trim().toLowerCase() };
    box.contacts.push(c); store.save(user); return send(res, 201, { contact: c });
  }
  m = p.match(/^\/api\/contacts\/([\w-]+)$/);
  if (m && req.method === 'DELETE') { box.contacts = box.contacts.filter((c) => c.id !== m[1]); store.save(user); return send(res, 200, { ok: true }); }

  return send(res, 404, { error: 'Not found' });
}

const api = http.createServer((req, res) => handle(req, res).catch((e) => { log.warn('api error: ' + e.message); send(res, 400, { error: e.message }); }));

function start() {
  return new Promise((resolve) => {
    smtp.listen(config.smtpPort, config.smtpHost, () => {
      log.info(`SMTP receiving for @${config.domain} on ${config.smtpHost}:${config.smtpPort}`);
      api.listen(config.apiPort, config.apiHost, () => {
        log.info(`API and web app on http://${config.apiHost}:${config.apiPort}`);
        log.info(`Outside mail: ${config.outsideMail.enabled ? 'relay via ' + config.outsideMail.fromAddress : config.directDelivery ? 'direct MX delivery' : 'off (local mail only)'}`);
        resolve();
      });
    });
  });
}
function stop() { return Promise.all([new Promise((r) => smtp.close(r)), new Promise((r) => api.close(r))]); }

if (require.main === module) start();
module.exports = { start, stop, store, config };
