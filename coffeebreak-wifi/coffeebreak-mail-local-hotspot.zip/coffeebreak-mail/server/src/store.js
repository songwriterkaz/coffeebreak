'use strict';
// Simple JSON-file mailbox storage. One file per user plus users.json.
// Writes are atomic (write temp file, then rename).
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class Store {
  constructor(dir) {
    this.dir = dir;
    this.boxDir = path.join(dir, 'mailboxes');
    fs.mkdirSync(this.boxDir, { recursive: true, mode: 0o700 });
    this.usersFile = path.join(dir, 'users.json');
    this.users = this._read(this.usersFile, {});
    this.statsFile = path.join(dir, 'stats.json');
    this.stats = this._read(this.statsFile, { relay: {} });
    this.cache = new Map();
  }
  _read(f, d) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } }
  _write(f, obj) {
    const tmp = f + '.' + process.pid + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(obj, null, 1), { mode: 0o600 });
    fs.renameSync(tmp, f);
  }
  // ---- users ----
  static hashPassword(pw, salt = crypto.randomBytes(16).toString('hex')) {
    const hash = crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex');
    return `scrypt$${salt}$${hash}`;
  }
  static verifyPassword(pw, stored) {
    const [, salt, hash] = String(stored).split('$');
    if (!salt || !hash) return false;
    const test = crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
    const want = Buffer.from(hash, 'hex');
    return want.length === test.length && crypto.timingSafeEqual(want, test);
  }
  hasUser(u) { return Object.prototype.hasOwnProperty.call(this.users, u); }
  addUser(username, password, displayName) {
    username = String(username).toLowerCase();
    if (!/^[a-z0-9][a-z0-9._-]{1,31}$/.test(username)) throw new Error('Username must be 2-32 letters, numbers, dots, dashes or underscores');
    if (!password || password.length < 8) throw new Error('Password must be at least 8 characters');
    if (this.hasUser(username)) throw new Error('That username is taken');
    this.users[username] = { username, displayName: displayName || username, password: Store.hashPassword(password), created: new Date().toISOString() };
    this._write(this.usersFile, this.users);
    return this.users[username];
  }
  checkLogin(username, password) {
    const u = this.users[String(username).toLowerCase()];
    if (!u) { Store.hashPassword('timing-equaliser'); return null; }
    return Store.verifyPassword(password, u.password) ? u : null;
  }
  // ---- mailboxes ----
  _boxFile(u) { return path.join(this.boxDir, u + '.json'); }
  box(u) {
    if (!this.cache.has(u)) this.cache.set(u, this._read(this._boxFile(u), { messages: [], contacts: [] }));
    return this.cache.get(u);
  }
  save(u) { this._write(this._boxFile(u), this.box(u)); }
  addMessage(u, msg) {
    const m = Object.assign({ id: crypto.randomUUID(), date: new Date().toISOString(), read: false, starred: false, folder: 'inbox' }, msg);
    this.box(u).messages.push(m);
    this.save(u);
    return m;
  }
  // ---- relay daily counter ----
  relayCountToday() {
    const day = new Date().toISOString().slice(0, 10);
    return this.stats.relay[day] || 0;
  }
  bumpRelay(n) {
    const day = new Date().toISOString().slice(0, 10);
    this.stats.relay = { [day]: (this.stats.relay[day] || 0) + n };
    this._write(this.statsFile, this.stats);
  }
}
module.exports = Store;
