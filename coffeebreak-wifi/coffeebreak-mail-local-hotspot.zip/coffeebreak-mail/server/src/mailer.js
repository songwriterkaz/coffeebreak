'use strict';
// Outgoing mail routing for Coffeebreak Mail.
//  1. Local addresses (@<domain>, default coffeebreak.local) are delivered straight
//     into the recipient's mailbox. Free, never leaves the server.
//  2. Outside addresses go through the optional "Outside mail" relay (the owner's
//     own email account over SMTP, e.g. Gmail with an app password), or
//  3. by direct MX delivery if directDelivery is on (needs a real domain + port 25).
const dns = require('dns').promises;
const nodemailer = require('nodemailer');
const log = require('./log');

function splitAddr(a) {
  const m = String(a).trim().toLowerCase().match(/^(?:.*<)?([^<>\s@]+)@([^<>\s@]+)>?$/);
  return m ? { local: m[1], domain: m[2], address: `${m[1]}@${m[2]}` } : null;
}

class Mailer {
  constructor(config, store) {
    this.config = config;
    this.store = store;
    this.relay = null;
    const r = config.outsideMail;
    if (r.enabled) {
      if (!r.host || !r.user || !r.pass || !r.fromAddress) {
        log.warn('Outside mail relay is enabled but host, user, pass or fromAddress is missing; outside mail is turned off');
        r.enabled = false;
      } else {
        this.relay = nodemailer.createTransport({
          host: r.host, port: r.port, secure: r.secure,
          auth: { user: r.user, pass: r.pass },
          requireTLS: !r.secure,
          tls: { rejectUnauthorized: r.rejectUnauthorized },
          logger: false, debug: false,   // never log credentials or SMTP transcripts
        });
        log.info(`Outside mail relay on: ${r.host}:${r.port}, sends as ${r.fromAddress}`);
      }
    }
  }
  isLocal(addr) { const a = splitAddr(addr); return !!a && a.domain === this.config.domain; }

  // msg: { fromUser, to:[], cc:[], subject, text, inReplyTo, references }
  async send(msg) {
    const user = this.store.users[msg.fromUser];
    const fromAddress = `${msg.fromUser}@${this.config.domain}`;
    const all = [...(msg.to || []), ...(msg.cc || [])].map(splitAddr);
    if (!all.length) throw new Error('Add at least one recipient');
    if (all.some((a) => !a)) throw new Error('One of the addresses is not valid');
    const local = all.filter((a) => a.domain === this.config.domain);
    const outside = all.filter((a) => a.domain !== this.config.domain);
    const results = [];
    const messageId = `<${require('crypto').randomUUID()}@${this.config.domain}>`;
    const base = {
      from: { name: user.displayName, address: fromAddress },
      to: msg.to, cc: msg.cc || [], subject: msg.subject || '(no subject)', text: msg.text || '',
      messageId, inReplyTo: msg.inReplyTo || null,
    };

    // 1. local delivery
    for (const a of local) {
      if (!this.store.hasUser(a.local)) { results.push({ to: a.address, ok: false, via: 'local', error: 'No such user on this server' }); continue; }
      this.store.addMessage(a.local, { ...base, folder: 'inbox' });
      results.push({ to: a.address, ok: true, via: 'local' });
    }

    // 2/3. outside delivery
    if (outside.length) {
      if (this.relay) results.push(...(await this._viaRelay(base, outside, user)));
      else if (this.config.directDelivery) results.push(...(await this._direct(base, outside)));
      else outside.forEach((a) => results.push({ to: a.address, ok: false, via: 'none', error: 'Outside mail is not set up on this server. Only @' + this.config.domain + ' addresses work.' }));
    }
    return { messageId, results, base };
  }

  async _viaRelay(base, outside, user) {
    const r = this.config.outsideMail;
    const used = this.store.relayCountToday();
    if (used + outside.length > r.dailyLimit) {
      return outside.map((a) => ({ to: a.address, ok: false, via: 'relay', error: `Daily outside mail limit (${r.dailyLimit}) reached. Try again tomorrow.` }));
    }
    // Mail goes out FROM the relay account's address (providers like Gmail rewrite
    // the sender anyway). The local sender is named in the display name and body.
    const sentBy = `${base.from.address}`;
    try {
      await this.relay.sendMail({
        from: { name: `${user.displayName} via ${r.fromName}`, address: r.fromAddress },
        replyTo: r.fromAddress,
        to: outside.map((a) => a.address).join(', '),
        subject: base.subject,
        text: `${base.text}\n\n--\nSent by ${sentBy} using Coffeebreak Mail`,
        messageId: base.messageId,
        inReplyTo: base.inReplyTo || undefined,
        headers: { 'X-Coffeebreak-Sender': sentBy },
      });
      this.store.bumpRelay(outside.length);
      log.info(`relay: ${sentBy} -> ${outside.length} outside recipient(s)`);
      return outside.map((a) => ({ to: a.address, ok: true, via: 'relay', sentAs: r.fromAddress }));
    } catch (e) {
      log.warn(`relay send failed for ${sentBy}: ${e.code || ''} ${e.responseCode || ''}`.trim());
      return outside.map((a) => ({ to: a.address, ok: false, via: 'relay', error: 'The outside mail account refused or could not be reached' }));
    }
  }

  async _direct(base, outside) {
    const out = [];
    const byDomain = {};
    outside.forEach((a) => (byDomain[a.domain] = byDomain[a.domain] || []).push(a));
    for (const [domain, addrs] of Object.entries(byDomain)) {
      try {
        const mx = (await dns.resolveMx(domain)).sort((x, y) => x.priority - y.priority);
        if (!mx.length) throw new Error('no MX');
        const t = nodemailer.createTransport({
          host: mx[0].exchange, port: 25, secure: false, name: this.config.hostname,
          opportunisticTLS: true, tls: { rejectUnauthorized: false }, logger: false,
          dkim: this.config.dkim || undefined,
        });
        await t.sendMail({ ...base, envelope: { from: base.from.address, to: addrs.map((a) => a.address) } });
        addrs.forEach((a) => out.push({ to: a.address, ok: true, via: 'direct' }));
      } catch (e) {
        log.warn(`direct delivery to ${domain} failed: ${e.code || e.message}`);
        addrs.forEach((a) => out.push({ to: a.address, ok: false, via: 'direct', error: 'Could not deliver to ' + domain }));
      }
    }
    return out;
  }
}
module.exports = { Mailer, splitAddr };
